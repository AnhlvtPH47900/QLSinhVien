﻿namespace DiemSinhVien
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            groupBox1 = new GroupBox();
            label3 = new Label();
            grDiem = new GroupBox();
            txtGDTC = new TextBox();
            txtTinHoc = new TextBox();
            txtTiengAnh = new TextBox();
            txtMa = new TextBox();
            txtTen = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            btnClear = new Button();
            dgv_ThongTin = new DataGridView();
            btn_Update = new Button();
            btn_Xoaa = new Button();
            txt_Timkiem = new TextBox();
            btn_TimKiem = new Button();
            groupBox1.SuspendLayout();
            grDiem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_ThongTin).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 49);
            label1.Name = "label1";
            label1.Size = new Size(54, 20);
            label1.TabIndex = 0;
            label1.Text = "Mã SV:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(354, 29);
            label2.Name = "label2";
            label2.Size = new Size(129, 31);
            label2.TabIndex = 1;
            label2.Text = "Giảng Viên";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_TimKiem);
            groupBox1.Controls.Add(txt_Timkiem);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(57, 63);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(811, 106);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tìm Kiếm ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(57, 415);
            label3.Name = "label3";
            label3.Size = new Size(205, 20);
            label3.TabIndex = 4;
            label3.Text = "3 Sinh Viên có điểm cao nhất ";
            // 
            // grDiem
            // 
            grDiem.Controls.Add(txtGDTC);
            grDiem.Controls.Add(txtTinHoc);
            grDiem.Controls.Add(txtTiengAnh);
            grDiem.Controls.Add(txtMa);
            grDiem.Controls.Add(txtTen);
            grDiem.Controls.Add(label8);
            grDiem.Controls.Add(label7);
            grDiem.Controls.Add(label6);
            grDiem.Controls.Add(label5);
            grDiem.Controls.Add(label4);
            grDiem.Location = new Point(57, 175);
            grDiem.Name = "grDiem";
            grDiem.Size = new Size(563, 237);
            grDiem.TabIndex = 5;
            grDiem.TabStop = false;
            // 
            // txtGDTC
            // 
            txtGDTC.Location = new Point(121, 193);
            txtGDTC.Name = "txtGDTC";
            txtGDTC.Size = new Size(393, 27);
            txtGDTC.TabIndex = 9;
            // 
            // txtTinHoc
            // 
            txtTinHoc.Location = new Point(121, 150);
            txtTinHoc.Name = "txtTinHoc";
            txtTinHoc.Size = new Size(393, 27);
            txtTinHoc.TabIndex = 8;
            // 
            // txtTiengAnh
            // 
            txtTiengAnh.Location = new Point(121, 105);
            txtTiengAnh.Name = "txtTiengAnh";
            txtTiengAnh.Size = new Size(393, 27);
            txtTiengAnh.TabIndex = 7;
            // 
            // txtMa
            // 
            txtMa.Location = new Point(121, 61);
            txtMa.Name = "txtMa";
            txtMa.Size = new Size(393, 27);
            txtMa.TabIndex = 6;
            // 
            // txtTen
            // 
            txtTen.Location = new Point(121, 28);
            txtTen.Name = "txtTen";
            txtTen.Size = new Size(393, 27);
            txtTen.TabIndex = 5;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(33, 200);
            label8.Name = "label8";
            label8.Size = new Size(45, 20);
            label8.TabIndex = 4;
            label8.Text = "GDTC";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(33, 157);
            label7.Name = "label7";
            label7.Size = new Size(56, 20);
            label7.TabIndex = 3;
            label7.Text = "TinHoc";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(32, 112);
            label6.Name = "label6";
            label6.Size = new Size(72, 20);
            label6.TabIndex = 2;
            label6.Text = "TiengAnh";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(29, 69);
            label5.Name = "label5";
            label5.Size = new Size(51, 20);
            label5.TabIndex = 1;
            label5.Text = "Mã SV";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(29, 35);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 0;
            label4.Text = "Họ Tên SV";
            // 
            // btnClear
            // 
            btnClear.Location = new Point(679, 368);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 29);
            btnClear.TabIndex = 9;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // dgv_ThongTin
            // 
            dgv_ThongTin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ThongTin.Location = new Point(49, 450);
            dgv_ThongTin.Name = "dgv_ThongTin";
            dgv_ThongTin.RowHeadersWidth = 51;
            dgv_ThongTin.RowTemplate.Height = 29;
            dgv_ThongTin.Size = new Size(780, 114);
            dgv_ThongTin.TabIndex = 10;
            // 
            // btn_Update
            // 
            btn_Update.Location = new Point(679, 210);
            btn_Update.Name = "btn_Update";
            btn_Update.Size = new Size(94, 29);
            btn_Update.TabIndex = 11;
            btn_Update.Text = "Cập Nhật";
            btn_Update.UseVisualStyleBackColor = true;
            // 
            // btn_Xoaa
            // 
            btn_Xoaa.Location = new Point(679, 296);
            btn_Xoaa.Name = "btn_Xoaa";
            btn_Xoaa.Size = new Size(94, 29);
            btn_Xoaa.TabIndex = 12;
            btn_Xoaa.Text = "Xóa";
            btn_Xoaa.UseVisualStyleBackColor = true;
            // 
            // txt_Timkiem
            // 
            txt_Timkiem.Location = new Point(121, 51);
            txt_Timkiem.Name = "txt_Timkiem";
            txt_Timkiem.Size = new Size(393, 27);
            txt_Timkiem.TabIndex = 1;
            // 
            // btn_TimKiem
            // 
            btn_TimKiem.Location = new Point(622, 55);
            btn_TimKiem.Name = "btn_TimKiem";
            btn_TimKiem.Size = new Size(94, 29);
            btn_TimKiem.TabIndex = 2;
            btn_TimKiem.Text = "Tìm Kiếm";
            btn_TimKiem.UseVisualStyleBackColor = true;
            btn_TimKiem.Click += btn_TimKiem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(923, 584);
            Controls.Add(btn_Xoaa);
            Controls.Add(btn_Update);
            Controls.Add(dgv_ThongTin);
            Controls.Add(btnClear);
            Controls.Add(grDiem);
            Controls.Add(label3);
            Controls.Add(groupBox1);
            Controls.Add(label2);
            Name = "Form2";
            Text = "Form2";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            grDiem.ResumeLayout(false);
            grDiem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_ThongTin).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private GroupBox groupBox1;
        private Button btnSearch;
        private TextBox txtMaSV;
        private Label label3;
        private GroupBox grDiem;
        private Label label9;
        private TextBox txtGDTC;
        private TextBox txtTinHoc;
        private TextBox txtTiengAnh;
        private TextBox txtMa;
        private TextBox txtTen;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Button btnNew;
        private Button btnSave;
        private Button btnDelete;
        private Button btnClear;
        private TextBox txtDiemTB;
        private DataGridView dgv_ThongTin;
        private Button btn_Update;
        private Button btn_Xoaa;
        private TextBox txt_Timkiem;
        private Button btn_TimKiem;
    }
}